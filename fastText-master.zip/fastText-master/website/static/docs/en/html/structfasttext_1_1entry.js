var structfasttext_1_1entry =
[
    [ "count", "structfasttext_1_1entry.html#ab1f793678a1669b826d48f8b9ddcee6a", null ],
    [ "subwords", "structfasttext_1_1entry.html#a0487be0781a1d71b9bb2a9c039c4be9b", null ],
    [ "type", "structfasttext_1_1entry.html#a345f716349f28b9a1a13e083b1cdb92d", null ],
    [ "word", "structfasttext_1_1entry.html#ae22a7e78ad207d2f90086a48a6f0d085", null ]
];