var searchData=
[
  ['binarylogistic',['binaryLogistic',['../classfasttext_1_1Model.html#a953cbd5ace20826dcc1453bb94e99de0',1,'fasttext::Model']]],
  ['buildtree',['buildTree',['../classfasttext_1_1Model.html#aadfc3b7eb7bbe05f024fbfb67ea25ffd',1,'fasttext::Model']]]
];
